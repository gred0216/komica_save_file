# komica_save_file

#

Save picture or uploaded file from [komica](https://komica.org/)

Every file on the current page will be download to a new folder under current working directory

Folder naming rule: board-name_index/thread-number_localtime

For example

綜合_11016927_2018-03-04_04-30

#


下載本地版上傳的圖檔或附件

當前頁面的所有檔案會保存在目前工作路徑下的新資料夾內

資料夾命名規則： 版名_index/討論串編號_當地時間

例如

綜合_11016927_2018-03-04_04-30

