from distutils.core import setup


setup(name='komica_save_file',
      version='1.0',
      description='save files from komica',
      author='gred0216',
      author_email='betacrunch12345@gmail.com',
      packages=[''],
      )
